import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

// --- CEREBRO DE LA APP (BASE DE DATOS INTEGRADA) ---
class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;
  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('servicio_tecnico_local.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    // Reemplazamos 'join' de path por una suma simple para evitar importar 'path.dart'
    final path = '$dbPath/$filePath';
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE trabajos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente TEXT NOT NULL,
        telefono TEXT,
        fecha TEXT NOT NULL,
        hora TEXT NOT NULL,
        descripcion TEXT NOT NULL,
        materiales TEXT,
        manoObra REAL,
        total REAL
      )
    ''');
  }

  Future<int> insertTrabajo(Map<String, dynamic> row) async {
    final db = await instance.database;
    return await db.insert('trabajos', row);
  }

  Future<List<Map<String, dynamic>>> getTrabajos() async {
    final db = await instance.database;
    return await db.query('trabajos', orderBy: 'id DESC');
  }

  Future<int> deleteTrabajo(int id) async {
    final db = await instance.database;
    return await db.delete('trabajos', where: 'id = ?', whereArgs: [id]);
  }
}

// --- ARRANQUE DE LA APP ---
void main() {
  runApp(const MiAppServicioTecnico());
}

class MiAppServicioTecnico extends StatelessWidget {
  const MiAppServicioTecnico({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Servicio Técnico',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const PantallaPrincipal(),
    );
  }
}

class PantallaPrincipal extends StatefulWidget {
  const PantallaPrincipal({Key? key}) : super(key: key);

  @override
  State<PantallaPrincipal> createState() => _PantallaPrincipalState();
}

class _PantallaPrincipalState extends State<PantallaPrincipal> {
  List<Map<String, dynamic>> _trabajos = [];

  @override
  void initState() {
    super.initState();
    _cargarTrabajos();
  }

  Future<void> _cargarTrabajos() async {
    final datos = await DatabaseHelper.instance.getTrabajos();
    setState(() {
      _trabajos = datos;
    });
  }

  // --- GENERADOR DE PDF ---
  Future<void> _generarPdfPresupuesto(Map<String, dynamic> trabajo) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Padding(
            padding: const pw.EdgeInsets.all(30),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text('PRESUPUESTO DE SERVICIO TÉCNICO',
                    style: pw.TextStyle(
                        fontSize: 22, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 10),
                pw.Divider(),
                pw.SizedBox(height: 15),
                pw.Text('Cliente: ${trabajo['cliente']}',
                    style: pw.TextStyle(fontSize: 14)),
                pw.Text('Teléfono: ${trabajo['telefono'] ?? "No especificado"}',
                    style: pw.TextStyle(fontSize: 14)),
                pw.Text(
                    'Fecha de Visita: ${trabajo['fecha']} - ${trabajo['hora']} hs',
                    style: pw.TextStyle(fontSize: 14)),
                pw.SizedBox(height: 25),
                pw.Text('Descripción del Trabajo:',
                    style: pw.TextStyle(
                        fontSize: 15, fontWeight: pw.FontWeight.bold)),
                pw.Text('${trabajo['descripcion']}',
                    style: pw.TextStyle(fontSize: 13)),
                pw.SizedBox(height: 25),
                pw.Text('Detalle de Costos:',
                    style: pw.TextStyle(
                        fontSize: 15, fontWeight: pw.FontWeight.bold)),
                pw.Text(
                    '- Materiales y Repuestos: \$${trabajo['materiales'] ?? "0.0"}',
                    style: pw.TextStyle(fontSize: 13)),
                pw.Text('- Mano de Obra: \$${trabajo['manoObra'] ?? "0.0"}',
                    style: pw.TextStyle(fontSize: 13)),
                pw.SizedBox(height: 20),
                pw.Divider(),
                pw.SizedBox(height: 10),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text('TOTAL ESTIMADO:',
                        style: pw.TextStyle(
                            fontSize: 16, fontWeight: pw.FontWeight.bold)),
                    pw.Text('\$${trabajo['total'] ?? "0.0"}',
                        style: pw.TextStyle(
                            fontSize: 16, fontWeight: pw.FontWeight.bold)),
                  ],
                ),
                pw.SizedBox(height: 50),
                pw.Align(
                  alignment: pw.Alignment.center,
                  child: pw.Text('Gracias por confiar en nuestro servicio.',
                      style: pw.TextStyle(
                          fontSize: 11, fontStyle: pw.FontStyle.italic)),
                )
              ],
            ),
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  void _abrirFormularioNuevoTrabajo() {
    final clienteController = TextEditingController();
    final telefonoController = TextEditingController();
    final descController = TextEditingController();
    final materialesController = TextEditingController();
    final manoObraController = TextEditingController();
    DateTime fechaSeleccionada = DateTime.now();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
          top: 20,
          left: 20,
          right: 20,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Nuevo Trabajo / Agenda',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              TextField(
                  controller: clienteController,
                  decoration:
                      const InputDecoration(labelText: 'Nombre del Cliente')),
              TextField(
                  controller: telefonoController,
                  decoration:
                      const InputDecoration(labelText: 'Teléfono de Contacto')),
              TextField(
                  controller: descController,
                  decoration: const InputDecoration(
                      labelText: 'Descripción del Trabajo / Falla')),
              TextField(
                  controller: materialesController,
                  decoration: const InputDecoration(
                      labelText: 'Costo de Materiales \$'),
                  keyboardType: TextInputType.number),
              TextField(
                  controller: manoObraController,
                  decoration:
                      const InputDecoration(labelText: 'Costo Mano de Obra \$'),
                  keyboardType: TextInputType.number),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  final mat = double.tryParse(materialesController.text) ?? 0.0;
                  final mano = double.tryParse(manoObraController.text) ?? 0.0;
                  final totalCalculado = mat + mano;

                  await DatabaseHelper.instance.insertTrabajo({
                    'cliente': clienteController.text,
                    'telefono': telefonoController.text,
                    'fecha':
                        "${fechaSeleccionada.day}/${fechaSeleccionada.month}/${fechaSeleccionada.year}",
                    'hora':
                        "${fechaSeleccionada.hour}:${fechaSeleccionada.minute.toString().padLeft(2, '0')}",
                    'descripcion': descController.text,
                    'materiales': materialesController.text,
                    'manoObra': mano,
                    'total': totalCalculado,
                  });

                  _cargarTrabajos();
                  Navigator.pop(ctx);
                },
                child: const Text('Guardar y Agendar'),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mis Servicios y Presupuestos'),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: _trabajos.isEmpty
          ? const Center(child: Text('No tenés visitas agendadas todavía.'))
          : ListView.builder(
              itemCount: _trabajos.length,
              itemBuilder: (context, index) {
                final t = _trabajos[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                  child: ListTile(
                    title: Text(t['cliente'],
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(
                        '${t['fecha']} - ${t['hora']} hs\n${t['descripcion']}\nTotal: \$${t['total']}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.picture_as_pdf,
                              color: Colors.red),
                          onPressed: () => _generarPdfPresupuesto(t),
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete, color: Colors.grey),
                          onPressed: () async {
                            await DatabaseHelper.instance
                                .deleteTrabajo(t['id']);
                            _cargarTrabajos();
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _abrirFormularioNuevoTrabajo,
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}
